from setuptools import setup

setup(
    name="SegPreEntrega",
    version="1.0",
    description="Example of Distributed Package - Python course from Coderhouse platform",
    author="Nicolas Calabro",
    author_email="nicolas.j.calabro@gmail.com",
    packages= ["packageClient"]
)